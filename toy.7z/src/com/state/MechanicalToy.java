package com.state;

/**
 * Created by Yelena_Khamitchina on 24.11.2016.
 */
public class MechanicalToy extends Toy implements Movement, MakingSounds{

    @Override
    public void sound() {

    }

    @Override
    public void move() {

    }
}
