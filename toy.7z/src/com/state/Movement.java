package com.state;

/**
 * Created by Yelena_Khamitchina on 25.11.2016.
 */
public interface Movement {
    void sound ();
}
